import json
import os
import psycopg2
import time


DATABASE_URL = 'postgres://zmqvexfoxzsxsb:926f9e2074ec1de1bddd7d59a79e06e066608c5888bdb28407fc33f751592d43@ec2-54-235-242-63.compute-1.amazonaws.com:5432/d8i0ojsph57uuc'

conn = psycopg2.connect(DATABASE_URL,sslmode='require')

cur = conn.cursor()

# mensaje de bienvenida para cuando se inicia la app directamente
WELCOME_MESSAGE = ("Welcome to Metapp. What activity do you want to start?")

# mensaje de titulo del skill
SKILLTITLE = "Metapp"

# mensaje al iniciar una actividad
START_ACTIVITY_MESSAGE = "Starting activity"

# mensaje al terminar la actividad o salir de la app
EXIT_SKILL_MESSAGE = "Thank you for using Metapp"

# mensaje de ayuda
# HELP_MESSAGE = "Nobody can help you now."
HELP_MESSAGE = "Please, try again."

# moar settings

# if you dont want to use cards in your skill, set this to false.
# if it's set to True, you will need an image for each item in your data.
USE_CARDS_FLAG = False

STATE_START = "Start"
CHECK_ORDER = "Check Order"

STATE = STATE_START


# ----------- clase de actividad ----------

class Activity:
    
    def __init__(self, numero, descripcion, order, respuesta):
        self.numero = numero
        self.desc = descripcion
        self.order = order
        self.respuesta = respuesta
        
class Opcion:
    
    def __init__(self, actividad, numero, nombre, desc, respuesta):
        self.actividad = actividad
        self.numero = numero
        self.nombre = nombre
        self.desc = desc
        self.respuesta = respuesta

# -------- seteo para ejemplo --------

OPCIONES = []

ACTIVIDADES = []
PASOS = []
SUBPASOS = []
PASOSDEFAULT = []

IDACTIV=0
IDSTEP=0
IDSUBSTEP=0

DEVICE= "ninguna"

ORDEN = []

MIEMBROS = []
USUARIOACTUAL = 0
GRUPOID = 0

SESION = 0

DEVICENAME = "Default"


# ---------- entry point --------

def lambda_handler(event, context):
    # TODO implement
    try:
        if event['request']['type'] == "LaunchRequest":
            return on_launch(event['context']['System'])
        elif event['request']['type'] == "IntentRequest":
            return on_intent(event['request'], event['session'])
        elif event['request']['type'] == "SessionEndedRequest":
            return on_session_ended(event['request'])
    except:
        msg= "Could not understand, please try again"
        attributes = {"state":globals()['STATE']}
        return response(attributes, response_plain_text(msg, False))
    
    return {
        "statusCode": 200,
        "body": json.dumps('Hello from Lambda!')
    }

# ------ exit point -----

def on_session_ended(request):
    EXIT_MESSAGE = "Thanks for using Metapp."
    attributes ={"status":globals()['STATE']}
    return response(attributes, response_plain_text(EXIT_MESSAGE, False))


# ------------ response handlers --------

def on_intent(request, session):
    
    global conn
    
    conn.rollback()
    
    intent = request['intent']
    intent_name = request['intent']['name']
    
    
    print("on_intent " +intent_name)
    #get_state(session)
    
    
    if 'dialogState' in request:
        #delegate to Alexa until dialog sequence is complete
        if request['dialogState'] == "STARTED" or request['dialogState'] == "IN_PROGRESS":
            return dialog_response("", False)
      
    #process the intents
    if intent_name == "StartActivity":
        return start_selected_activity(request, intent, session)
    elif intent_name== "Test":
        return test(request, intent, session)
    elif intent_name== "ViewSteps":
        return view_steps(request, intent, session)
    elif intent_name== "CheckSteps":
        return check_steps(request, intent, session)
    elif intent_name== "ViewSubSteps":
        return view_substeps(request, intent, session)
    elif intent_name== "CheckSubSteps":
        return check_substeps(request, intent, session)
    elif intent_name== "AnswerSubSteps":
        return answer_substeps(request, intent, session)
    elif intent_name== "AnswerSubStepsWord":
        return answer_substepsword(request, intent, session)
    elif intent_name == "StartOrder":
        return start_order(request, intent, session)
    elif intent_name == "CheckOrder":
        return check_order(request, intent, session)
    elif intent_name == "StartAnalisis":
        return analisis_actividad(request, intent, session)
    elif intent_name == "GetDeviceName":
        return get_device(request, intent, session)
    elif intent_name == "RegisterDevice":
        return register_device(request, intent, session)
    elif intent_name == "NameDevice":
        return name_device(request, intent, session)
    elif intent_name == "CheckOption":
        return check_option(request, intent, session)
    elif intent_name == "AnswerOption":
        return answer_option(request, intent, session)
    elif intent_name == "FinalAnswer":
        return final_answer(request, intent, session)
    else:
        print("invalid intent reply with help")
        return do_help()
        
def test(request, intent, session):
    global cur
    global ACTIVIDADES
    cur.execute("SELECT * FROM actividades WHERE id = 1;")
    valor = (cur.fetchone())
    ACTIVIDADES = valor
    print(ACTIVIDADES[0])
    cur.execute("SELECT * FROM pasos WHERE actividad = "+str(ACTIVIDADES[0])+" ;")
    valores = (cur.fetchall())
    print(valores)
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(valor[1], False))
        
def name_device(request, intent, session):
    global DEVICENAME
    
    DEVICENAME = intent['slots']['nombre']['value'].lower()
    
    msg = "This device is now named " + str(DEVICENAME)
    
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(msg, False))

    
def get_device(request, intent, session):
    global DEVICENAME
    
    msg = "Then name of this device is " + str(DEVICENAME)
    
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(msg, False))
    
def register_device(request, intent, session):
    global DEVICENAME
    global conn
    global cur
    global DEVICE
    
    usuario = int(intent['slots']['number']['value'])
    
    if DEVICENAME == "Default":
        msg = "Please name this device first"
        attributes = {"state":globals()['STATE']}
        return response(attributes, response_plain_text(msg, False))
    
    cur.execute("INSERT INTO dispositivos(\"user\", \"dispositivo\", \"nombre\", \"created_at\") VALUES (%s, %s, %s, %s);", (usuario, DEVICE, DEVICENAME, time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())))
    conn.commit()
    
    msg = "The device named " + str(DEVICENAME) + " has been registered under user number " + str(usuario)
    
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(msg, False))
    
def start_selected_activity(request, intent, session):
    global conn
    global cur
    global ACTUAL
    global ACTIVIDADES
    global DEVICE
    global IDACTIV
    global MIEMBROS
    global GRUPOID
    global SESION
    #return response(attributes, response_plain_text("test", False))
    cur.execute('SELECT id, curso FROM sesiones WHERE "id" = '+str(SESION)+';')
    val = (cur.fetchall())
    cur.execute("SELECT * FROM actividades WHERE id = "+str(val[0][1])+" ;")
    valor = (cur.fetchone())
    if not valor:
        attributes = {"state":globals()['STATE']}
        return response(attributes, response_plain_text("There is no activity with that ID.", False))
    ACTIVIDADES = valor
    activ = ACTIVIDADES
    ACTUAL = activ
    IDACTIV = ACTIVIDADES[0]
    cur.execute("UPDATE alexa_session SET actividad=(%s) WHERE alexa=(%s)", (IDACTIV, str(GRUPOID)))
    conn.commit()
    for persona in MIEMBROS:
        save_log(persona[2], 3, "Iniciando la actividad " + str(IDACTIV))
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(activ[2], False))

# code to start a custom activity besides the selected one by the techer
def start_activity(request, intent, session):
    global conn
    global cur
    global ACTUAL
    global ACTIVIDADES
    global DEVICE
    global IDACTIV
    global MIEMBROS
    global GRUPOID
    #return response(attributes, response_plain_text("test", False))
    for key, val in intent['slots'].items():
        if val.get('value'):
            lval = val['value'].lower()
            cur.execute("SELECT * FROM actividades WHERE id = "+str(lval)+" ;")
            valor = (cur.fetchone())
            if not valor:
                attributes = {"state":globals()['STATE']}
                return response(attributes, response_plain_text("There is no activity with that ID.", False))
            ACTIVIDADES = valor
            activ = ACTIVIDADES
            ACTUAL = activ
            IDACTIV = ACTIVIDADES[0]
            
            cur.execute("UPDATE alexa_session SET actividad=(%s) WHERE alexa=(%s)", (str(lval), str(GRUPOID)))
            conn.commit()
            for persona in MIEMBROS:
                save_log(persona[2], 3, "Iniciando la actividad " + str(IDACTIV))
            
            attributes = {"state":globals()['STATE']}
            return response(attributes, response_plain_text(activ[2], False))
            
def view_steps(request, intent, session):
    global ACTUAL
    global cur
    global ACTIVIDADES
    global PASOSDEFAULT
    global MIEMBROS
    if not ACTIVIDADES:
        attributes = {"state":globals()['STATE']}
        return response(attributes, response_plain_text("First start an activity", False))
    cur.execute("SELECT * FROM pasos WHERE actividad = "+str(ACTIVIDADES[0])+" ;")
    valores = (cur.fetchall())
    if PASOSDEFAULT is []:
        PASOSDEFAULT = valores
    msg =""
    num = 0
    for valor in valores:
        num = num+1
        msg= msg+str(num)+", "+str(valor[2]+". ")
    for persona in MIEMBROS:
        save_log(persona[2], 4, "Viendo los pasos")
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(msg, False))
    
def check_steps(request, intent, session):
    global ACTUAL
    global cur
    global conn
    global ACTIVIDADES
    global PASOS
    global DEVICE
    global IDSTEP
    global MIEMBROS
    global GRUPOID
    if not ACTIVIDADES:
        attributes = {"state":globals()['STATE']}
        return response(attributes, response_plain_text("First start an activity", False))
    cur.execute("SELECT * FROM pasos WHERE actividad = "+str(ACTIVIDADES[0])+" ;")
    valores = (cur.fetchall())
    msg = ""
    for key, val in intent['slots'].items():
        if val.get('value'):
            lval = val['value'].lower()
            num = int(lval)
            num = num - 1
            if num > len(valores):
                attributes = {"state":globals()['STATE']}
                return response(attributes, response_plain_text("There is no step like that.", False))
            msg = str(num+1)+", "+str(valores[num][2])+": "+str(valores[num][3])+"."
            PASOS = valores[num]
            
            IDSTEP = PASOS[0]
            
            cur.execute("UPDATE alexa_session SET paso=(%s) WHERE alexa=(%s)", (num, str(GRUPOID)))
            conn.commit()
            
            for persona in MIEMBROS:
                save_log(persona[2], 5, "Revisando paso " + str(IDSTEP))
            attributes = {"state":globals()['STATE']}
            return response(attributes, response_plain_text(msg, False))
            
def view_substeps(request, intent, session):
    global ACTUAL
    global cur
    global ACTIVIDADES
    global PASOS
    global SUBPASOS
    global IDSTEP
    global MIEMBROS
    if not PASOS:
        attributes = {"state":globals()['STATE']}
        return response(attributes, response_plain_text("First check a step", False))
    cur.execute("SELECT * FROM sub_pasos WHERE pasos = "+str(PASOS[0])+" ;")
    valores = (cur.fetchall())
    msg =""
    num = 0
    for valor in valores:
        num = num+1
        msg= msg+str(num)+", "+str(valor[2]+". ")
    for persona in MIEMBROS:
        save_log(persona[2], 6, "Viendo los subpasos del paso " + str(IDSTEP))
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(msg, False))
    
def check_substeps(request, intent, session):
    global ACTUAL
    global cur
    global ACTIVIDADES
    global PASOS
    global SUBPASOS
    global MIEMBROS
    global IDSTEP
    global IDSUBSTEP
    global USUARIOACTUAL
    
    if not PASOS:
        attributes = {"state":globals()['STATE']}
        return response(attributes, response_plain_text("First check a step", False))
    cur.execute("SELECT * FROM sub_pasos WHERE pasos = "+str(PASOS[0])+" ;")
    valores = (cur.fetchall())
    msg = ""
    for key, val in intent['slots'].items():
        if val.get('value'):
            lval = val['value'].lower()
            num = int(lval)
            num = num - 1
            if num > len(valores):
                attributes = {"state":globals()['STATE']}
                return response(attributes, response_plain_text("There is no substep like that.", False))
            msg = str(num+1)+", "+str(valores[num][2])+": "+str(valores[num][3])+"."
            SUBPASOS = valores[num]
            IDSUBSTEP = SUBPASOS[0]
            lugarmiembro = num % (len(MIEMBROS))
            persona = MIEMBROS[lugarmiembro][3]
            USUARIOACTUAL = MIEMBROS[lugarmiembro][2]
            msg = persona + ", please answer this:" + msg
            save_log(USUARIOACTUAL, 7, "Revisando dentro del paso " + str(IDSTEP) + " el subpaso " + str(IDSUBSTEP) + " en la posicion " + str(num))
            attributes = {"state":globals()['STATE']}
            return response(attributes, response_plain_text(msg, False))
            
def answer_substeps(request, intent, session):
    global ACTUAL
    global cur
    global ACTIVIDADES
    global PASOS
    global SUBPASOS
    global IDSTEP
    global IDSUBSTEP
    global MIEMBROS
    global USUARIOACTUAL
    
    if not SUBPASOS:
        attributes = {"state":globals()['STATE']}
        return response(attributes, response_plain_text("First check a substep", False))
    msg = "incorrect"
    respinteger = int(intent['slots']['integer']['value'].lower())
    respdecimal = int(intent['slots']['decimal']['value'].lower())
    if '.' in SUBPASOS[4]:
        integer = int((SUBPASOS[4].split('.'))[0])
        decimal = int((SUBPASOS[4].split('.'))[1])
    else:
        integer = int(SUBPASOS[4])
        decimal = 0
    if (integer == respinteger) and (decimal == respdecimal):
        msg = "correct"
    save_log(USUARIOACTUAL, 10, "Respondiendo el subpaso " + str(IDSUBSTEP) + " con la respuesta " + str(respinteger) + "." + str(respdecimal) + " y el resultado fue " + str(msg))
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(msg, False))
    
def answer_substepsword(request, intent, session):
    global ACTUAL
    global cur
    global ACTIVIDADES
    global PASOS
    global SUBPASOS
    global IDSUBSTEP
    global USUARIOACTUAL
    if not SUBPASOS:
        attributes = {"state":globals()['STATE']}
        return response(attributes, response_plain_text("First check a substep", False))
    msg = "incorrect"
    respuesta = intent['slots']['answerword']['value'].lower()
    if (SUBPASOS[4].lower() == respuesta):
        msg = "correct"
    save_log(USUARIOACTUAL, 9, "Respondiendo el subpaso " + str(IDSUBSTEP) + " con la respuesta " + str(respuesta) + " y el resultado fue " + str(msg))
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(msg, False))

def start_order(request, intent, session):
    global ACTUAL
    global ACTIVIDADES
    global cur
    global ORDEN
    global IDACTIV
    global MIEMBROS
    msg = "Tell the order of the steps in the form of: The first step is the step number one"
    cur.execute("SELECT * FROM pasos WHERE actividad = "+str(ACTIVIDADES[0])+" AND \"order\" <> 0 ORDER BY \"order\";")
    valores = (cur.fetchall())
    ORDEN = valores
    for persona in MIEMBROS:
        save_log(persona[2], 11, "Iniciando el orden de los pasos de la actividad " + str(IDACTIV))
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(msg, False))
    
def check_order(request, intent, session):
    global ORDEN
    global cur
    global ACTIVIDADES
    global IDACTIV
    global MIEMBROS
    
    lug=int(intent['slots']['lugar']['value'])
    pas=int(intent['slots']['paso']['value'])
    if ((lug>len(ORDEN)) or (pas>len(PASOSDEFAULT))):
        msg = "That's not a step or position"
    elif ORDEN[lug-1][0] == PASOSDEFAULT[pas-1][0]:
        msg= "correct"
    else:
        msg= "incorrect"
    for persona in MIEMBROS:
        save_log(persona[2], 12, "Se ha ubicado el paso " + str(pas) + " en el lugar " + str(lug))
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(msg, False))
    
def check_option(request, intent, session):
    global ACTUAL
    message = "There's no option like that"
    for key, val in intent['slots'].items():
        if val.get('value'):
            for opcion in OPCIONES:
                if opcion.actividad == ACTUAL.numero:
                    if val['value'] == opcion.numero:
                        message = opcion.desc
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(message, False))
    
def analisis_actividad(request, intent, session):
    msg = "The analisis of this activity is:"
    msg = msg+" "+str(data_steps_mistakes())
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(msg, False))
    
def answer_option(request, intent, session):
    global ACTUAL
    message = "There's no option like that."
    for opcion in OPCIONES:
        if opcion.actividad == ACTUAL.numero:
            if opcion.numero == str(intent['slots']['number']['value']):
                if opcion.respuesta == str(intent['slots']['answer']['value']):
                    message = "Correct"
                else:
                    message = "Wrong"
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(message, False))
    
def final_answer(request, intent, session):
    message = "Wrong"
    if ACTUAL.respuesta == str(intent['slots']['answer']['value']):
        message = "Congratulations, you ahve completed the activity. Yay!"
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(message, False))
    
def porfa_profe():
    message = "Give this student a good grade"
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(message, False))
    
def do_help():
    global STATE
    STATE = STATE_START
    attributes ={"status":globals()['STATE']}
    return response(attributes, response_plain_text(HELP_MESSAGE, False))

def on_launch(system):
    global conn
    global cur
    global ACTIVIDADES
    global PASOS
    global IDACTIV
    global IDSTEP
    global DEVICE
    global MIEMBROS
    global PASOSDEFAULT
    global SESION
    global GRUPOID
    
    device = system['device']['deviceId']
    
    DEVICE = device
    
    cur.execute('SELECT id, grupo, dispositivo FROM grupos_dispositivos WHERE "dispositivo" = \''+str(DEVICE)+'\' ORDER BY "id" desc;')
    grupodispositivo = (cur.fetchall())
    
    try:
        GRUPOID = grupodispositivo[0][1]
    except:
        GRUPOID = 0
    cur.execute('SELECT id, "id-sesion" FROM grupos WHERE "id" = '+str(GRUPOID)+';')
    val = (cur.fetchall())
    try:
        SESION = val[0][1]
    except:
        SESION = 0
    
    cur.execute('SELECT grupos_usuarios.id, "id-grupo", "id-usuario", name FROM grupos_usuarios JOIN users ON "id-usuario" = users.id WHERE "id-grupo" = '+str(GRUPOID)+';')
    MIEMBROS = (cur.fetchall())
    
    cur.execute("SELECT * FROM alexa_session WHERE alexa='"+str(GRUPOID)+"';")
    valor = (cur.fetchone())
    
    
    if valor is not None:
        if valor[2] is not 0:
            cur.execute("SELECT * FROM actividades WHERE id="+str(valor[2])+" ;")
            ACTIVIDADES = (cur.fetchone())
            IDACTIV = ACTIVIDADES[0]
            cur.execute("SELECT * FROM pasos WHERE actividad = "+str(valor[2])+" ;")
            valores = (cur.fetchall())
            PASOS = valores[valor[3]]
            PASOSDEFAULT = valores
        for persona in MIEMBROS:
            save_log(persona[2], 1, "Volviendo a la app")
        attributes = {"state":globals()['STATE']}
        return response(attributes, response_plain_text("Welcome back to metapp", False))
    else:
        cur.execute("INSERT INTO alexa_session(alexa, actividad, paso) VALUES (%s, %s, %s);", (str(GRUPOID), 0, 0))
        conn.commit()
        for persona in MIEMBROS:
            save_log(7, 1, "Iniciando la app")
        return get_welcome_message()
    
def get_state(session):
    
    global STATE
    
    if 'state' in session['attributes']:
        STATE = session['attributes']['state']
    else:
        STATE = STATE_START
        
        
        
# ----------- internal functions sector

def save_log(usuario, tipo, valor):
    global ACTUAL
    global STATE
    global conn
    global cur
    global ACTIVIDADES
    global PASOS
    global IDACTIV
    global IDSTEP
    global DEVICE
    global SESION
    
    # revisando si las variables necesarias estan seteadas
    if ACTIVIDADES is None or ACTIVIDADES is []:
        ACTIVIDADES = [0]
    if PASOS is None or PASOS is []:
        PASOS = [0]
    if IDSTEP is None or IDSTEP is []:
        IDSTEP = 0
    if DEVICE is None or DEVICE is '':
        DEVICE = "Default"
    if SESION is None or SESION is '':
        SESION = 0
    
    # guardado del log
    cur.execute("INSERT INTO logs(\"Id-usuario\", \"Id-dispositivo\", \"Id-sesion\", \"Id-actividad\", \"Id-tipo\", \"Valor\", \"created_at\") VALUES (%s, %s, %s, %s, %s, %s, %s);", (usuario, DEVICE, SESION, IDACTIV, tipo, valor, time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())))
    
    # guardado de los cambios en la base de datos
    conn.commit()
    

# ----- funciones de analisis, retroalimentacion
# obtiene el paso con mas errores
def data_steps_mistakes():
    global ACTUAL
    global STATE
    global cur
    global IDACTIV
    global IDSTEP
    global DEVICE
    global SESION
    
    if IDSTEP is None or IDSTEP is []:
        IDSTEP = 0
    if DEVICE is None or DEVICE is '':
        DEVICE = "Default"
    if SESION is None or SESION is '':
        SESION = 0
    
    cur.execute("SELECT * FROM logs WHERE \"Id-dispositivo\" = '"+str(DEVICE)+"' AND \"Id-actividad\" = "+str(IDACTIV)+" AND (\"Id-tipo\" = 9 OR \"Id-tipo\" = 10);")
    varrespuestas = (cur.fetchall())
    
    if varrespuestas is None:
        return "Not enough data"
    
    cur.execute("SELECT * FROM pasos WHERE actividad = "+str(IDACTIV)+" ;")
    varpasos = (cur.fetchall())
    
    if varpasos == []:
        return "Not enough data"
    
    
    conteopasos = len(varpasos)
    
    if conteopasos == 0:
        conteopasos = 1
    conteoerrores = [0]*conteopasos
    
    maxerror = None
    
    for resp in varrespuestas:
        respuestasplit = resp[6].split()
        if respuestasplit[-1] == 'incorrect':
            cur.execute("SELECT id, pasos FROM sub_pasos WHERE id = "+str(respuestasplit[3]))
            var = (cur.fetchone())
            for num in range(conteopasos):
                var2 = varpasos[num][0]
                if int(var[1]) == var2:
                    conteoerrores[num] = conteoerrores[num] + 1
    maxnum = max(conteoerrores)
    if maxnum > 0:
        maxerror = varpasos[conteoerrores.index(maxnum)]
        msg = "The highest amount of mistakes was "+str(maxnum)+" , on the step "+str(maxerror[2])+" "+str(maxerror[3])
    else:
        msg = "No mistakes where made, congratulations"
    
    return msg
    
    
        
        
    

# ---------- response string formatters -------

def get_welcome_message():
    
    attributes = {"state":globals()['STATE']}
    return response(attributes, response_plain_text(WELCOME_MESSAGE, False))

# -------- speech response handlers --------

def response_plain_text(output, endsession):
    
    return {
        'outputSpeech': {
            'type': 'PlainText',
            'text': output
        },
        'reprompt': {
            'type': 'PlainText',
            'text': "Waiting for an answer"
        },
        'shouldEndSession': endsession
    }
    
def response_ssml_text(output, endsession):

    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': "<speak>" +output +"</speak>"
        },
        'shouldEndSession': endsession
    }
    
def response_ssml_text_and_prompt(output, endsession, reprompt_text):

    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': "<speak>" +output +"</speak>"
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': "<speak>" +reprompt_text +"</speak>"
            }
        },
        'shouldEndSession': endsession
    }
    
def response_ssml_cardimage_prompt(title, output, endsession, cardtext, abbreviation, reprompt):

    smallimage = get_smallimage(abbreviation)
    largeimage = get_largeimage(abbreviation)
    return {
        'card': {
            'type': 'Standard',
            'title': title,
            'text': cardtext,
            'image':{
                'smallimageurl':smallimage,
                'largeimageurl':largeimage
            },
        },
        'outputSpeech': {
            'type': 'SSML',
            'ssml': "<speak>" +output +"</speak>"
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': "<speak>" +reprompt +"</speak>"
            }
        },
        'shouldEndSession': endsession
    }
    
def response_ssml_text_reprompt(output, endsession, reprompt_text):

    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': "<speak>" +output +"</speak>"
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': "<speak>" +reprompt_text +"</speak>"
            }
        },
        'shouldEndSession': endsession
    }

def dialog_response(attributes, endsession):

    return {
        'version': '1.0',
        'sessionAttributes': attributes,
        'response':{
            'directives': [
                {
                    'type': 'Dialog.Delegate'
                }
            ],
            'shouldEndSession': endsession
        }
    }
    

def response(attributes, speech_response):
    
    return {
        'version': '1.0',
        'sessionAtributes': attributes,
        'response': speech_response
    }